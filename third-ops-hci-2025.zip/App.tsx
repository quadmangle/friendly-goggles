
import React, { useState, useContext } from 'react';
import { GlobalContext } from './contexts/GlobalContext';
import type { ModalType, ServiceKey } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import ServiceCardsGrid from './components/ServiceCardsGrid';
import FABs from './components/FABs';
import MobileNav from './components/MobileNav';
import Footer from './components/Footer';
import ServiceModal from './components/modals/ServiceModal';
import { SERVICES_DATA } from './constants';
import JoinModal from './components/modals/JoinModal';
import ContactModal from './components/modals/ContactModal';
import ChatbotModal from './components/modals/ChatbotModal';

const App: React.FC = () => {
  const { theme, language } = useContext(GlobalContext);
  const [modal, setModal] = useState<{ type: ModalType; showBackdrop: boolean }>({ type: 'NONE', showBackdrop: true });
  const [selectedService, setSelectedService] = useState<ServiceKey | null>(null);

  const openModal = (type: ModalType, serviceKey?: ServiceKey, showBackdrop = true) => {
    if (serviceKey) {
      setSelectedService(serviceKey);
    }
    setModal({ type, showBackdrop });
  };

  const closeModal = () => {
    setModal({ type: 'NONE', showBackdrop: true });
    setSelectedService(null);
  };

  const serviceModalData = selectedService ? SERVICES_DATA[selectedService][language].modal : null;

  return (
    <div className={`${theme === 'dark' ? 'dark' : ''} transition-colors duration-300`}>
      <div className="bg-gradient-to-br from-sky-400 via-violet-400 to-rose-400 dark:from-[#191632] dark:to-[#1a1930] text-light-text dark:text-dark-text min-h-screen font-sans pb-20 transition-colors duration-300">
        <Header />
        <main>
          <Hero />
          <ServiceCardsGrid onCardClick={(key) => openModal('SERVICE', key)} />
        </main>
        
        <FABs onOpenModal={openModal} />
        <MobileNav onOpenModal={openModal} />
        
        <Footer />

        {modal.type === 'SERVICE' && serviceModalData && (
          <ServiceModal
            isOpen={true}
            onClose={closeModal}
            data={serviceModalData}
            onOpenContactModal={() => {
              closeModal();
              openModal('CONTACT', undefined, false);
            }}
            onOpenChatbotModal={() => {
              closeModal();
              openModal('CHATBOT', undefined, false);
            }}
          />
        )}
        {modal.type === 'JOIN' && <JoinModal isOpen={true} onClose={closeModal} showBackdrop={modal.showBackdrop} />}
        {modal.type === 'CONTACT' && <ContactModal isOpen={true} onClose={closeModal} showBackdrop={modal.showBackdrop} />}
        {modal.type === 'CHATBOT' && <ChatbotModal isOpen={true} onClose={closeModal} showBackdrop={modal.showBackdrop} />}
      </div>
    </div>
  );
};

export default App;