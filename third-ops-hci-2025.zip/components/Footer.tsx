
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-white/20 dark:bg-dark-footer/50 backdrop-blur-lg text-gray-800 dark:text-white text-base text-center py-4 fixed left-0 bottom-0 z-40 font-medium rounded-t-2xl tracking-wide border-t border-white/30 dark:border-white/10">
      © 2025 OPS Online Support
    </footer>
  );
};

export default Footer;