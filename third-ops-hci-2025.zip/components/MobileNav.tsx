import React, { useState, useEffect, useRef, useContext } from 'react';
import type { ModalType } from '../types';
import { GlobalContext } from '../contexts/GlobalContext';

interface MobileNavProps {
  onOpenModal: (type: ModalType, serviceKey: undefined, showBackdrop: boolean) => void;
}

const MobileNav: React.FC<MobileNavProps> = ({ onOpenModal }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const { language, setLanguage, theme, setTheme } = useContext(GlobalContext);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
        setIsServicesOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleMenu = () => {
    if (isMenuOpen) {
      setIsServicesOpen(false);
    }
    setIsMenuOpen(prev => !prev);
  };

  const createFab = (title: string, icon: string, action: () => void, isMain: boolean = false) => (
    <button
      onClick={() => { action(); if (!isMain) toggleMenu(); }}
      title={title}
      className="w-14 h-14 shrink-0 rounded-full bg-white dark:bg-gray-700 text-accent dark:text-primary flex items-center justify-center text-2xl shadow-md transition-transform hover:scale-110"
    >
      <i className={icon}></i>
    </button>
  );

  const serviceLinks = [
    { en: 'Business Operations', es: 'Operaciones'},
    { en: 'Contact Center', es: 'Centro de Contacto'},
    { en: 'IT Support', es: 'Soporte IT'},
    { en: 'Professionals', es: 'Profesionales'},
  ];

  return (
    <div ref={containerRef} className="lg:hidden fixed bottom-4 right-4 z-[999] flex justify-end items-center">
      {/* Action Buttons Container */}
      <div className={`flex items-center gap-3 transition-all duration-300 ease-in-out mr-3 ${isMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-90 pointer-events-none'}`}>
        {createFab('Join Us', 'fa-thin fa-user-plus', () => onOpenModal('JOIN', undefined, false))}
        {createFab('Contact Us', 'fa-thin fa-envelope', () => onOpenModal('CONTACT', undefined, false))}
        {createFab('Chatbot', 'fa-thin fa-comment-dots', () => onOpenModal('CHATBOT', undefined, false))}
        
        {/* Services Button with Drop-up Panel */}
        <div className="relative">
          <button
            onClick={() => setIsServicesOpen(p => !p)}
            title="Services"
            className="w-14 h-14 shrink-0 rounded-full bg-white dark:bg-gray-700 text-accent dark:text-primary flex items-center justify-center text-2xl shadow-md transition-transform hover:scale-110"
          >
            <i className="fa-thin fa-cogs"></i>
          </button>
          {isServicesOpen && (
            <div className="absolute bottom-full right-0 mb-2 w-52 bg-gray-100/95 dark:bg-gray-900/95 backdrop-blur-sm rounded-2xl shadow-lg p-3 animate-fadein">
              {serviceLinks.map(link => (
                <a href="#" key={link.en} className="block text-gray-800 dark:text-gray-200 text-base py-1 px-2 rounded-md transition-colors hover:bg-gray-200 dark:hover:bg-gray-700">{link[language]}</a>
              ))}
              <div className="h-px bg-gray-300 dark:bg-gray-600 my-1"></div>
              <button onClick={() => { setTheme(theme === 'light' ? 'dark' : 'light'); setIsServicesOpen(false); }} className="w-full text-left text-gray-800 dark:text-gray-200 text-base py-1 px-2 rounded-md transition-colors hover:bg-gray-200 dark:hover:bg-gray-700 capitalize">{theme === 'light' ? 'Dark Mode' : 'Light Mode'}</button>
              <button onClick={() => { setLanguage(language === 'en' ? 'es' : 'en'); setIsServicesOpen(false); }} className="w-full text-left text-gray-800 dark:text-gray-200 text-base py-1 px-2 rounded-md transition-colors hover:bg-gray-200 dark:hover:bg-gray-700">Español / English</button>
            </div>
          )}
        </div>
      </div>

      {/* Main Toggle FAB */}
      <button
        onClick={toggleMenu}
        title="Menu"
        aria-expanded={isMenuOpen}
        className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-primary text-white flex items-center justify-center text-3xl shadow-lg cursor-pointer transition-all duration-300 ease-in-out hover:from-primary hover:to-accent animate-shine"
      >
        <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-plus'} transition-transform duration-300 ${isMenuOpen ? 'rotate-45' : ''}`}></i>
      </button>
    </div>
  );
};

export default MobileNav;