import React, { useState } from 'react';
import type { ModalType } from '../types';

interface FABsProps {
  onOpenModal: (type: ModalType, serviceKey: undefined, showBackdrop: boolean) => void;
}

const FABs: React.FC<FABsProps> = ({ onOpenModal }) => {
  const [isOpen, setIsOpen] = useState(false);

  const fabs = [
    { title: 'Services', icon: 'fa-thin fa-bars', action: () => document.querySelector('.grid-container')?.scrollIntoView({ behavior: 'smooth' }) },
    { title: 'Join Us', icon: 'fa-thin fa-user-plus', action: () => onOpenModal('JOIN', undefined, false) },
    { title: 'Contact Us', icon: 'fa-thin fa-envelope', action: () => onOpenModal('CONTACT', undefined, false) },
    { title: 'Chatbot', icon: 'fa-thin fa-comment-dots', action: () => onOpenModal('CHATBOT', undefined, false) },
  ];

  return (
    <div className="hidden lg:flex fixed bottom-4 right-4 z-50 flex-col gap-4 items-end">
      {/* Sub FABs */}
      <div className="flex flex-col items-end gap-4">
        {fabs.map((fab, index) => (
          <div
            key={fab.title}
            className={`transition-all duration-200 ease-in-out ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3 pointer-events-none'}`}
            style={{ transitionDelay: `${isOpen ? (fabs.length - 1 - index) * 40 : 0}ms` }}
          >
            <button
              onClick={() => {
                fab.action();
                setIsOpen(false);
              }}
              title={fab.title}
              className="w-14 h-14 rounded-full bg-white dark:bg-gray-700 text-accent dark:text-primary flex items-center justify-center text-2xl border-none shadow-md cursor-pointer transition-transform duration-200 ease-in-out hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent"
            >
              <i className={fab.icon}></i>
            </button>
          </div>
        )).reverse()}
      </div>

      {/* Main FAB */}
      <button
        onClick={() => setIsOpen(prev => !prev)}
        title={isOpen ? "Close Menu" : "Open Menu"}
        aria-expanded={isOpen}
        className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-primary text-white flex items-center justify-center text-3xl border-none shadow-lg shadow-accent/30 cursor-pointer transition-all duration-300 ease-in-out hover:from-primary hover:to-accent hover:shadow-xl hover:shadow-primary/40 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent animate-shine"
      >
        <i className={`fas ${isOpen ? 'fa-times' : 'fa-plus'} transition-transform duration-300 ${isOpen ? 'rotate-90' : ''}`}></i>
      </button>
    </div>
  );
};

export default FABs;