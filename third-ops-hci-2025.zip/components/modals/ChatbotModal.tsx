
import React, { useState, useEffect, useRef, useContext } from 'react';
import type { ModalProps, ChatMessage } from '../../types';
import { GlobalContext } from '../../contexts/GlobalContext';
import ModalWrapper from './ModalWrapper';
import { useDraggable } from '../../hooks/useDraggable';
import { streamChatResponse, resetChat } from '../../services/geminiService';

const ChatbotModal: React.FC<ModalProps> = ({ isOpen, onClose, showBackdrop = true }) => {
    const { language, setLanguage, theme, setTheme } = useContext(GlobalContext);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    
    const modalRef = useRef<HTMLDivElement>(null);
    const headerRef = useRef<HTMLDivElement>(null);
    const chatLogRef = useRef<HTMLDivElement>(null);
    
    useDraggable(modalRef, headerRef);

    const l = (en: string, es: string) => language === 'en' ? en : es;

    useEffect(() => {
      // Proactive welcome message
      if (isOpen && messages.length === 0) {
        setMessages([{ role: 'system', text: l('Welcome to OPS! How can I assist you today?', '¡Bienvenido a OPS! ¿Cómo puedo ayudarte hoy?') }]);
      }
      
      // Reset chat session when modal is closed
      return () => {
        if (!isOpen) {
          resetChat();
          setMessages([]);
        }
      }
    }, [isOpen, language]);

    useEffect(() => {
        if (chatLogRef.current) {
            chatLogRef.current.scrollTop = chatLogRef.current.scrollHeight;
        }
    }, [messages]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;

        const userMessage: ChatMessage = { role: 'user', text: input };
        const newMessages: ChatMessage[] = [...messages, userMessage];
        setMessages(newMessages);
        const currentInput = input;
        setInput('');
        setIsLoading(true);

        const botMessage: ChatMessage = { role: 'bot', text: '' };
        setMessages(prev => [...prev, botMessage]);

        await streamChatResponse(newMessages, currentInput, (chunk) => {
            setMessages(prev => {
                const updatedMessages = [...prev];
                updatedMessages[updatedMessages.length - 1].text = chunk;
                return updatedMessages;
            });
        });

        setIsLoading(false);
    };
    
    const initialPosition = !showBackdrop ? 'right-4 bottom-28' : '';

    return (
        <ModalWrapper isOpen={isOpen} onClose={onClose} showBackdrop={showBackdrop} backdropClassName="!pt-0" modalClassName={`w-[96vw] max-w-lg min-w-[310px] sm:h-[66vh] h-[80vh] max-h-[700px] ${initialPosition}`}>
            <div ref={modalRef} className="bg-dark-modal text-dark-text rounded-3xl shadow-2xl h-full flex flex-col overflow-hidden">
                <header ref={headerRef} className="flex justify-between items-center p-3 px-4 bg-gradient-to-r from-primary to-accent text-white font-semibold cursor-move select-none">
                    <span>{l('OPS AI Chatbot', 'Chatbot OPS AI')}</span>
                    <div className="flex items-center gap-2 text-sm">
                        <button onClick={() => setLanguage(language === 'en' ? 'es' : 'en')} className="opacity-90 hover:opacity-100">{l('ES', 'EN')}</button>
                        <span>|</span>
                        <button 
                          onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')} 
                          className="opacity-90 hover:opacity-100 capitalize w-16 text-center"
                        >
                          {theme === 'light' ? l('Dark', 'Oscuro') : l('Light', 'Claro')}
                        </button>
                        <button onClick={onClose} className="ml-2 text-xl font-bold opacity-90 hover:opacity-100">&times;</button>
                    </div>
                </header>

                <div ref={chatLogRef} className="flex-1 overflow-y-auto p-4 bg-[#1b0e2d] text-sm space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`max-w-[90%] w-fit py-2 px-3.5 rounded-2xl ${
                            msg.role === 'user' 
                            ? 'ml-auto bg-primary text-black rounded-br-none' 
                            : msg.role === 'bot' 
                              ? 'mr-auto bg-[#321b53] text-white rounded-bl-none whitespace-pre-wrap'
                              : 'mx-auto bg-transparent text-accent/80 text-center text-xs'
                        }`}>
                           {msg.text}
                           {msg.role === 'bot' && isLoading && index === messages.length - 1 && <span className="inline-block w-2 h-2 ml-1 bg-white rounded-full animate-pulse"></span>}
                        </div>
                    ))}
                     {isLoading && messages[messages.length - 1]?.role !== 'bot' && (
                        <div className="mr-auto bg-[#321b53] text-white rounded-bl-none whitespace-pre-wrap max-w-[90%] w-fit py-2 px-3.5 rounded-2xl">
                            <span className="italic text-gray-400">{l('Chattia is typing...', 'Chattia está escribiendo...')}</span>
                        </div>
                    )}
                </div>

                <div className="bg-[#220f3a] border-t border-accent/50 p-3">
                    <form onSubmit={handleSend} className="flex items-center gap-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder={l('Type your message...', 'Escriba su mensaje...')}
                            className="flex-1 bg-transparent border-none text-white text-base p-2 focus:outline-none"
                            required
                            maxLength={256}
                            disabled={isLoading}
                        />
                        <button 
                            type="submit" 
                            disabled={isLoading || !input.trim()}
                            className="flex items-center justify-center w-10 h-10 bg-accent border-none text-white font-semibold rounded-lg cursor-pointer transition-all duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed group"
                        >
                            <i className="fas fa-arrow-right"></i>
                        </button>
                    </form>
                </div>
            </div>
        </ModalWrapper>
    );
};

export default ChatbotModal;