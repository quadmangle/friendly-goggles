
import React, { useContext, useRef } from 'react';
import { GlobalContext } from '../../contexts/GlobalContext';
import { useDraggable } from '../../hooks/useDraggable';
import type { ModalProps, ServiceModalData } from '../../types';
import ModalWrapper from './ModalWrapper';

interface ServiceModalProps extends ModalProps {
  data: ServiceModalData;
  onOpenContactModal: () => void;
  onOpenChatbotModal: () => void;
}

const ModalButton: React.FC<{ children: React.ReactNode; onClick?: () => void; href?: string; isCta?: boolean; }> = ({ children, onClick, href, isCta = false }) => {
    const commonClasses = "border-none rounded-2xl py-2.5 px-5 text-base cursor-pointer font-semibold mt-2 transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-dark-modal focus:ring-accent";
    const ctaClasses = "bg-gradient-to-r from-primary to-accent text-white hover:from-accent hover:to-primary";
    const defaultClasses = "bg-[#eae6fc] dark:bg-gray-700 text-[#4d1d79] dark:text-gray-200 hover:bg-[#dcd6f0] dark:hover:bg-gray-600";
  
    if (href) {
      return <a href={href} target="_blank" rel="noopener noreferrer" className={`${commonClasses} ${isCta ? ctaClasses : defaultClasses}`}>{children}</a>;
    }
    return <button onClick={onClick} className={`${commonClasses} ${isCta ? ctaClasses : defaultClasses}`}>{children}</button>;
};

const ServiceModal: React.FC<ServiceModalProps> = ({ isOpen, onClose, data, onOpenContactModal, onOpenChatbotModal }) => {
  const { language } = useContext(GlobalContext);
  const modalRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  useDraggable(modalRef, headerRef);

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose} modalClassName="w-[96vw] max-w-lg min-w-[310px]">
      <div ref={modalRef} className="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl p-8 pt-6 relative cursor-default">
        <button onClick={onClose} className="absolute top-4 right-7 text-3xl font-bold text-accent border-none bg-none cursor-pointer z-10">&times;</button>
        <div ref={headerRef} className="flex gap-5 items-center mb-4 cursor-move">
          <img src={data.img} alt={data.imgAlt} className="w-16 h-16 object-cover rounded-2xl border-2 border-accent/50" />
          <h2 className="text-xl font-bold uppercase tracking-wider">{data.title}</h2>
        </div>
        <div className="mb-4 text-base">{data.content}</div>
        <div className="bg-gray-100 dark:bg-dark-bg text-accent/80 dark:text-accent/60 rounded-xl mb-4 p-4 text-center">{data.video}</div>
        <ul className="mb-5 ml-5 list-disc space-y-1 text-base">
          {data.features.map(feature => <li key={feature}>{feature}</li>)}
        </ul>
        <div className="flex gap-3 justify-end flex-wrap mt-5">
          <ModalButton href={data.learn}>{language === 'en' ? 'Learn More' : 'Más Información'}</ModalButton>
          <ModalButton onClick={onOpenChatbotModal}>{language === 'en' ? 'Ask Chattia' : 'Preguntar a Chattia'}</ModalButton>
          <ModalButton onClick={onOpenContactModal} isCta>{language === 'en' ? 'Contact Us' : 'Contáctanos'}</ModalButton>
          <ModalButton onClick={onClose}>{language === 'en' ? 'Cancel' : 'Cancelar'}</ModalButton>
        </div>
      </div>
    </ModalWrapper>
  );
};

export default ServiceModal;
