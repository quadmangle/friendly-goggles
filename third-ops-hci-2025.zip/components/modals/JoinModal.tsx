
import React, { useContext, useRef, useState } from 'react';
import { GlobalContext } from '../../contexts/GlobalContext';
import { useDraggable } from '../../hooks/useDraggable';
import type { ModalProps } from '../../types';
import ModalWrapper from './ModalWrapper';

interface DynamicSectionProps {
  title: string;
  language: 'en' | 'es';
  placeholder: string;
}

const DynamicSection: React.FC<DynamicSectionProps> = ({ title, language, placeholder }) => {
  const [items, setItems] = useState<string[]>([]);
  const [isAccepted, setIsAccepted] = useState(false);

  const l = (en: string, es: string) => language === 'en' ? en : es;

  const handleAddItem = () => {
    if (items.length > 0 && items[items.length - 1].trim() === '') {
      // Prevent adding new if last is empty
      return;
    }
    setItems([...items, '']);
  };

  const handleRemoveItem = () => {
    if (items.length > 0) {
      setItems(items.slice(0, -1));
    }
  };
  
  const handleItemChange = (index: number, value: string) => {
    const newItems = [...items];
    newItems[index] = value;
    setItems(newItems);
  };

  const handleAccept = () => {
      if(items.length === 0 || items.some(item => item.trim() === '')) {
          alert(l('Please fill out all fields before accepting.', 'Por favor, complete todos los campos antes de aceptar.'));
          return;
      }
      setIsAccepted(true);
  }

  return (
    <div className={`p-4 mt-6 border rounded-lg ${isAccepted ? 'border-green-500' : 'border-dashed border-gray-400 dark:border-gray-600'}`}>
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-semibold text-lg">{title}{isAccepted && ' ✅'}</h3>
        {!isAccepted && (
            <div>
              <button type="button" onClick={handleAddItem} className="w-7 h-7 rounded-full bg-primary text-white font-bold text-xl leading-none" title={l('Add field', 'Añadir campo')}>+</button>
              <button type="button" onClick={handleRemoveItem} className="w-7 h-7 ml-2 rounded-full bg-red-500 text-white font-bold text-xl leading-none" title={l('Remove last field', 'Eliminar último campo')}>-</button>
            </div>
        )}
      </div>
      <div className="space-y-2">
        {items.map((item, index) => (
          <input 
            key={index} 
            type="text" 
            value={item}
            onChange={(e) => handleItemChange(index, e.target.value)}
            placeholder={placeholder}
            disabled={isAccepted}
            className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent focus:border-transparent disabled:opacity-70"
            />
        ))}
      </div>
      {items.length > 0 && (
        <div className="mt-3">
          {isAccepted ? (
            <button type="button" onClick={() => setIsAccepted(false)} className="py-1 px-4 rounded bg-yellow-500 text-black font-semibold">{l('Edit', 'Editar')}</button>
          ) : (
            <button type="button" onClick={handleAccept} className="py-1 px-4 rounded bg-green-500 text-white font-semibold">{l('Accept', 'Aceptar')}</button>
          )}
        </div>
      )}
    </div>
  );
};


const JoinModal: React.FC<ModalProps> = ({ isOpen, onClose, showBackdrop = true }) => {
  const { language } = useContext(GlobalContext);
  const modalRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  useDraggable(modalRef, headerRef);

  const l = (en: string, es: string) => language === 'en' ? en : es;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Application submitted!');
    onClose();
  };
  
  const initialPosition = !showBackdrop ? 'right-4 bottom-28' : '';

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose} showBackdrop={showBackdrop} modalClassName={`w-[96vw] max-w-lg min-w-[310px] ${initialPosition}`}>
      <div ref={modalRef} className="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl p-6 relative max-h-[80vh] flex flex-col">
        <header ref={headerRef} className="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-700 cursor-move">
          <h2 className="text-2xl font-bold text-primary">{l('Join Us', 'Únete a Nosotros')}</h2>
          <button onClick={onClose} className="text-3xl font-bold text-accent/80 hover:text-accent">&times;</button>
        </header>
        
        <form onSubmit={handleSubmit} className="overflow-y-auto flex-grow pr-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 mt-4">
                <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-1">{l('Name', 'Nombre')}</label>
                    <input type="text" id="name" name="name" placeholder={l('Enter your name', 'Ingresa tu nombre')} required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent focus:border-transparent"/>
                </div>
                <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">{l('Email', 'Correo Electrónico')}</label>
                    <input type="email" id="email" name="email" placeholder={l('Enter your email', 'Ingresa tu correo')} required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent focus:border-transparent"/>
                </div>
                <div>
                    <label htmlFor="phone" className="block text-sm font-medium mb-1">{l('Phone', 'Teléfono')}</label>
                    <input type="tel" id="phone" name="phone" placeholder={l('Enter your phone', 'Ingresa tu teléfono')} required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent focus:border-transparent"/>
                </div>
            </div>
          
            <DynamicSection title={l('Skills', 'Habilidades')} language={language} placeholder={l('Enter a skill', 'Ingrese una habilidad')} />
            <DynamicSection title={l('Education', 'Educación')} language={language} placeholder={l('Enter degree/institution', 'Ingrese título/institución')} />
            <DynamicSection title={l('Certifications', 'Certificaciones')} language={language} placeholder={l('Enter a certification', 'Ingrese una certificación')} />
            
            <div className="mt-6">
                <label htmlFor="interest" className="block text-sm font-medium mb-1">{l('What are you interested in?', '¿En qué estás interesado?')}</label>
                <select id="interest" required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent focus:border-transparent">
                    <option value="" disabled selected>{l('Select an option', 'Seleccione una opción')}</option>
                    <option>{l('Business Operations', 'Operaciones Empresariales')}</option>
                    <option>{l('Contact Center', 'Centro de Contacto')}</option>
                    <option>{l('IT Support', 'Soporte IT')}</option>
                    <option>{l('Professionals', 'Profesionales')}</option>
                </select>
            </div>

            <div className="mt-6">
                <label htmlFor="about" className="block text-sm font-medium mb-1">{l('Tell us about yourself', 'Cuéntanos sobre ti')}</label>
                <textarea id="about" rows={4} placeholder={l('Your summary here...', 'Tu resumen aquí...')} className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent focus:border-transparent"></textarea>
            </div>
            
            <div className="flex justify-center pt-6 mt-4 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" className="py-3 px-8 rounded-xl bg-primary text-white font-semibold hover:bg-accent-dark transition-colors shadow-lg hover:shadow-xl w-40">{l('Submit', 'Enviar')}</button>
            </div>
        </form>
      </div>
    </ModalWrapper>
  );
};

export default JoinModal;