import { GoogleGenAI } from "https://esm.sh/@google/genai@^1.15.0";

const $ = (selector, context = document) => context.querySelector(selector);
const $$ = (selector, context = document) => Array.from(context.querySelectorAll(selector));

// --- CONSTANTS --- //
const SERVICES_DATA = {
    ops: {
        en: { title: "BUSINESS OPERATIONS", icon: "fa-thin fa-briefcase", desc: "Streamline your processes, maximize efficiency, ensure compliance, and scale your business with precision.", modal: { title: "BUSINESS OPERATIONS", img: "https://picsum.photos/seed/OPS/96/96", imgAlt: "Business Operations", content: "Detailed content about our Business Operations services. We help optimize your processes, boost efficiency, and drive growth through strategic operational support. Key areas: process optimization, supply chain management, quality assurance.", video: "Video placeholder", features: ["Workflow digitization & automation", "Logistics & inventory efficiency", "Risk & compliance frameworks (NIST, ISO, CISA)", "Performance metric dashboards & analytics", "Remote training & Lean operations"], learn: "#" } },
        es: { title: "OPERACIONES EMPRESARIALES", icon: "fa-thin fa-briefcase", desc: "Optimice procesos, mejore la eficiencia, asegure cumplimiento y escale su empresa con precisión.", modal: { title: "SOBRE OPERACIONES EMPRESARIALES", img: "https://picsum.photos/seed/OPS/96/96", imgAlt: "Operaciones Empresariales", content: "Contenido detallado sobre nuestros servicios de Operaciones Empresariales. Ayudamos a optimizar sus procesos, mejorar la eficiencia e impulsar el crecimiento mediante el apoyo operativo estratégico. Las áreas clave incluyen la optimización de procesos, la gestión de la cadena de suministro y el aseguramiento de la calidad.", video: "Video placeholder", features: ["Digitalización y automatización del flujo de trabajo", "Estrategias de eficiencia logística e inventario", "Marcos de riesgo y cumplimiento (alineados a NIST, ISO, CISA)", "Cuadros de métricas de rendimiento y análisis", "Capacitación remota y operaciones Lean"], learn: "#" } }
    },
    cc: {
        en: { title: "CONTACT CENTER", icon: "fa-thin fa-headset", desc: "Enhance customer engagement with multilingual, multichannel support—24/7, data-driven, and empathetic.", modal: { title: "CONTACT CENTER", img: "https://picsum.photos/seed/CC/96/96", imgAlt: "Contact Center", content: "Explore our comprehensive Contact Center solutions to elevate customer satisfaction and engagement at every touchpoint. We offer inbound/outbound calls, multichannel support (email, chat, social), and advanced analytics.", video: "Video placeholder", features: ["24/7 inbound/outbound call management", "Multilingual chat/email support", "CRM integration (e.g., HubSpot, Salesforce)", "Social media engagement & sentiment tracking", "Customer experience analytics & quality monitoring"], learn: "#" } },
        es: { title: "CENTRO DE CONTACTO", icon: "fa-thin fa-headset", desc: "Mejore la experiencia del cliente con soporte multicanal y multilingüe—24/7, datos y empatía.", modal: { title: "SOBRE EL CENTRO DE CONTACTO", img: "https://picsum.photos/seed/CC/96/96", imgAlt: "Centro de Contacto", content: "Explore nuestras soluciones integrales de Centro de Contacto diseñadas para mejorar la satisfacción y el compromiso del cliente en todos los puntos de contacto. Ofrecemos servicios de llamadas entrantes y salientes, soporte multicanal (correo electrónico, chat, redes sociales) y análisis avanzados.", video: "Video placeholder", features: ["Gestión de llamadas entrantes y salientes 24/7", "Sorte por chat y correo electrónico en varios idiomas", "Integración con plataformas CRM (por ejemplo, HubSpot, Salesforce)", "Interacción en redes sociales y seguimiento de sentimiento", "Análisis de experiencia del cliente y monitoreo de calidad"], learn: "#" } }
    },
    it: {
        en: { title: "IT SUPPORT", icon: "fa-thin fa-laptop-code", desc: "Proactive, secure, real-time tech help, cloud management, and cyber defense for every business size.", modal: { title: "IT SUPPORT", img: "https://picsum.photos/seed/IT/96/96", imgAlt: "IT Support", content: "Our IT Support services deliver reliable, timely assistance to keep your systems running smoothly and securely: help desk, network monitoring, cybersecurity, and cloud infrastructure management.", video: "Video placeholder", features: ["24/7 tech support & remote troubleshooting", "Real-time network & system monitoring", "Cybersecurity audits, patching, threat detection", "Cloud infrastructure setup & maintenance", "NIST, CISA, OPS Core CyberSec compliance"], learn: "#" } },
        es: { title: "SOPORTE IT", icon: "fa-thin fa-laptop-code", desc: "Asistencia técnica proactiva y segura en tiempo real, gestión en la nube y ciberdefensa para cualquier tamaño de empresa.", modal: { title: "SOBRE SOPORTE IT", img: "https://picsum.photos/seed/IT/96/96", imgAlt: "Soporte IT", content: "Nuestros servicios de Soporte de TI brindan asistencia confiable y oportuna para mantener sus sistemas funcionando sin problemas y de forma segura. Los servicios incluyen soporte de mesa de ayuda, monitoreo de red, servicios de cibersecurity y gestión de infraestructura en la nube.", video: "Video placeholder", features: ["Soporte técnico 24/7 y solución remota de problemas", "Monitoreo en tiempo real de red y sistemas", "Auditorías de ciberseguridad, parches y detección de amenazas", "Configuración y mantenimiento de infraestructura en la nube", "Cumplimiento con NIST, CISA y políticas OPS Core CyberSec"], learn: "#" } }
    },
    pro: {
        en: { title: "PROFESSIONALS", icon: "fa-thin fa-user-tie", desc: "OPS-vetted talent for IT, HR, projects, finance—contract or full-time, ready when you are.", modal: { title: "PROFESSIONALS", img: "https://picsum.photos/seed/PRO/96/96", imgAlt: "Professionals", content: "Access our network of highly qualified and experienced professionals for your project or long-term staffing. Experts in IT, project management, finance, HR. OPS-vetted, NDA, compliance trained.", video: "Video placeholder", features: ["Remote IT professionals (SysAdmins, DevOps, Analysts)", "Project managers & agile consultants", "Finance and accounting professionals", "HR and recruitment experts", "OPS-vetted talent with NDA, compliance and role-specific training", "Ask AI"], learn: "#" } },
        es: { title: "PROFESIONALES", icon: "fa-thin fa-user-tie", desc: "Talento validado por OPS para TI, RRHH, proyectos y finanzas—contrato o tiempo completo, listo para usted.", modal: { title: "SOBRE PROFESIONALES", img: "https://picsum.photos/seed/PRO/96/96", imgAlt: "Profesionales", content: "Acceda a nuestra red de profesionales altamente cualificados y experimentados para satisfacer sus necesidades específicas de proyectos o de personal a largo plazo. Proporcionamos expertos en diversos campos, incluyendo TI, gestión de proyectos, finanzas y recursos humanos, asegurando que obtenga el talento adecuado para su negocio.", video: "Video placeholder", features: ["Profesionales IT remotos (SysAdmins, DevOps, Analistas)", "Gerentes de proyecto y consultores ágiles", "Profesionales de finanzas y contabilidad", "Expertos en recursos humanos y reclutamiento", "Talento validado por OPS con NDA, capacitación en cumplimiento y capacitación específica para el rol", "Preguntar AI"], learn: "#" } }
    }
};

// --- STATE MANAGEMENT --- //
const state = {
    theme: 'light',
    language: 'en',
    modal: { type: 'NONE', showBackdrop: true },
    isFabsOpen: false,
    isMobileMenuOpen: false,
    isMobileServicesOpen: false,
};

function setState(newState) {
    Object.assign(state, newState);
    render();
}

// --- GEMINI SERVICE --- //
let chat;
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY is not set. Chatbot will use simulated responses.");
}

const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

const initializeChat = () => {
    if (!ai) return null;
    if (!chat) {
        chat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: "You are 'Chattia', a helpful and friendly AI assistant for OPS, a company providing Business Operations, Contact Center, IT Support, and Professional services. Your tone is professional yet approachable. Keep responses concise and to the point. You can answer questions about the company's services. Do not make up information you don't know. If asked something unrelated to OPS, politely decline.",
            },
        });
    }
    return chat;
};

const streamChatResponse = async (history, newMessage, onChunk) => {
    if (!ai) {
        const simulatedResponse = "This is a simulated response as the AI model is not configured. I can help with Business Operations, Contact Centers, IT Support, and finding skilled Professionals. How can I assist you today?";
        const words = simulatedResponse.split(' ');
        for (let i = 0; i < words.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 50));
            onChunk(words.slice(0, i + 1).join(' '));
        }
        return;
    }
    try {
        const chatInstance = initializeChat();
        if (!chatInstance) throw new Error("Chat could not be initialized.");
        const stream = await chatInstance.sendMessageStream({ message: newMessage });
        let text = '';
        for await (const chunk of stream) {
            text += chunk.text;
            onChunk(text);
        }
    } catch (error) {
        console.error("Error streaming chat response:", error);
        onChunk("I'm sorry, I'm having trouble connecting right now. Please try again later.");
    }
};

const resetChat = () => { chat = null; };

// --- UTILS --- //
const l = (en, es) => state.language === 'en' ? en : es;

function makeDraggable(modalElement, handleElement) {
    let isDragging = false;
    let startPos = { x: 0, y: 0 };
    let initialModalPos = { x: 0, y: 0 };

    const onMouseDown = (e) => {
        if (handleElement.contains(e.target)) {
            isDragging = true;
            modalElement.classList.add('dragging');
            const rect = modalElement.getBoundingClientRect();
            initialModalPos = { x: rect.left, y: rect.top };
            startPos = { x: e.clientX, y: e.clientY };

            Object.assign(modalElement.style, {
                position: 'fixed',
                left: `${initialModalPos.x}px`,
                top: `${initialModalPos.y}px`,
                right: 'auto',
                bottom: 'auto',
                transform: 'none',
            });
            e.preventDefault();
        }
    };

    const onMouseMove = (e) => {
        if (isDragging) {
            const dx = e.clientX - startPos.x;
            const dy = e.clientY - startPos.y;
            modalElement.style.left = `${initialModalPos.x + dx}px`;
            modalElement.style.top = `${initialModalPos.y + dy}px`;
        }
    };

    const onMouseUp = () => {
        if (isDragging) {
            isDragging = false;
            modalElement.classList.remove('dragging');
        }
    };

    handleElement.addEventListener('mousedown', onMouseDown);
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
}


// --- MODAL MANAGEMENT --- //
function openModal(type, options = { showBackdrop: true, data: null }) {
    setState({ modal: { type, ...options } });
}
function closeModal() {
    if (state.modal.type === 'CHATBOT') resetChat();
    setState({ modal: { type: 'NONE', showBackdrop: true } });
}

// --- TEMPLATES --- //
const AppTemplate = () => `
  <div class="bg-gradient-to-br from-sky-400 via-violet-400 to-rose-400 dark:from-[#191632] dark:to-[#1a1930] text-light-text dark:text-dark-text min-h-screen font-sans pb-20 transition-colors duration-300">
    ${HeaderTemplate()}
    <main>
      ${HeroTemplate()}
      ${ServiceCardsGridTemplate()}
    </main>
    ${FABsTemplate()}
    ${MobileNavTemplate()}
    ${FooterTemplate()}
  </div>
`;

const HeaderTemplate = () => {
    const navLinks = [
        { en: 'Business Operations', es: 'Operaciones' },
        { en: 'Contact Center', es: 'Centro de Contacto' },
        { en: 'IT Support', es: 'Soporte IT' },
        { en: 'Professionals', es: 'Profesionales' },
    ];
    return `
    <header class="w-full max-w-6xl mx-auto flex items-center justify-between p-5 sm:px-8 font-semibold bg-transparent">
      <span class="font-bold text-4xl text-accent tracking-widest drop-shadow-logo-glow select-none">OPS</span>
      <nav class="hidden lg:flex gap-9">
        ${navLinks.map(link => `<a href="#" class="text-lg relative transition-colors duration-200 hover:text-primary focus:text-primary outline-none">${link[state.language]}</a>`).join('')}
      </nav>
      <div class="flex gap-2">
        <button id="lang-toggle" class="bg-primary text-white rounded-md py-1.5 px-4 font-bold text-base transition-colors duration-200 hover:bg-accent focus:bg-accent outline-none">
          ${state.language === 'en' ? 'ES' : 'EN'}
        </button>
        <button id="theme-toggle" class="bg-primary text-white rounded-md py-1.5 px-4 font-bold text-base transition-colors duration-200 hover:bg-accent focus:bg-accent outline-none capitalize">
          ${state.theme === 'light' ? 'Dark' : 'Light'}
        </button>
      </div>
    </header>
  `;
};

const HeroTemplate = () => {
    const content = {
        en: { title: "Scale your business with\n24/7 expert support", subtitle: "OPS provides managed services, IT solutions, and remote professionals to drive your growth.", button: "BOOK A CONSULTATION", },
        es: { title: "Escale su negocio con\nsoporte experto 24/7", subtitle: "OPS ofrece servicios gestionados, soluciones de TI y profesionales remotos para impulsar su crecimiento.", button: "RESERVAR UNA CONSULTA", },
    };
    return `
    <section class="bg-transparent text-center py-12 px-4 max-w-4xl mx-auto text-[#12253f] dark:text-gray-200">
      <h1 class="text-4xl md:text-5xl font-bold mb-3 leading-tight whitespace-pre-line animate-fade-in-up" style="animation-delay: 100ms; opacity: 0;">
        ${content[state.language].title}
      </h1>
      <p class="text-base md:text-lg text-[#3d4754] dark:text-gray-400 mb-7 max-w-2xl mx-auto animate-fade-in-up" style="animation-delay: 200ms; opacity: 0;">
        ${content[state.language].subtitle}
      </p>
      <button class="bg-[#12253f] dark:bg-accent text-white border-none py-3 px-8 font-semibold text-sm rounded-lg cursor-pointer transition-transform duration-300 ease-in-out hover:scale-105 animate-fade-in-up" style="animation-delay: 300ms; opacity: 0;">
        ${content[state.language].button}
      </button>
    </section>
  `;
};

const ServiceCardsGridTemplate = () => `
  <div class="w-[min(75rem,_100%)] mx-auto mt-11 p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    ${Object.keys(SERVICES_DATA).map((key, index) => {
        const service = SERVICES_DATA[key][state.language];
        return `
        <div data-service-key="${key}" class="service-card min-h-[170px] p-7 rounded-3xl gap-4 grid grid-cols-[1fr_auto] grid-rows-[auto_1fr_auto] bg-white/70 dark:bg-dark-card text-[#251541] dark:text-[#f3ecfe] shadow-card-light dark:shadow-card-dark backdrop-blur-lg border border-white/50 dark:border-white/20 transition-all duration-200 ease-in-out cursor-pointer overflow-hidden relative hover:-translate-y-1 hover:scale-105 hover:shadow-card-light-hover dark:hover:shadow-accent/20 animate-fade-in-up"
             style="animation-delay: ${200 + index * 100}ms; opacity: 0;" tabindex="0" role="button">
          <div class="text-base font-semibold tracking-wider uppercase self-end">${service.title}</div>
          <div class="text-3xl self-end justify-self-end bg-clip-text text-transparent bg-gradient-to-tr from-primary to-accent drop-shadow-icon-glow-light dark:drop-shadow-icon-glow-dark">
            <i class="${service.icon}"></i>
          </div>
          <div class="col-span-2 mt-2.5 text-sm"><p>${service.desc}</p></div>
          <div class="col-span-2 mt-3 h-0.5 bg-gradient-to-r from-primary to-accent"></div>
        </div>
      `;
    }).join('')}
  </div>
`;

const FABsTemplate = () => {
    const fabs = [
        { title: 'Chatbot', icon: 'fa-thin fa-comment-dots', action: "openModal('CHATBOT', { showBackdrop: false })" },
        { title: 'Contact Us', icon: 'fa-thin fa-envelope', action: "openModal('CONTACT', { showBackdrop: false })" },
        { title: 'Join Us', icon: 'fa-thin fa-user-plus', action: "openModal('JOIN', { showBackdrop: false })" },
        { title: 'Services', icon: 'fa-thin fa-bars', action: "$('.grid').scrollIntoView({ behavior: 'smooth' })" },
    ];

    return `
    <div id="fabs-container" class="hidden lg:flex fixed bottom-4 right-4 z-50 flex-col gap-4 items-end">
      <div class="flex flex-col items-end gap-4">
        ${fabs.map((fab, index) => `
          <div class="sub-fab transition-all duration-200 ease-in-out ${state.isFabsOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3 pointer-events-none'}"
               style="transition-delay: ${state.isFabsOpen ? index * 40 : 0}ms">
            <button data-action="${fab.action}" title="${fab.title}" class="w-14 h-14 rounded-full bg-white dark:bg-gray-700 text-accent dark:text-primary flex items-center justify-center text-2xl border-none shadow-md cursor-pointer transition-transform duration-200 ease-in-out hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent">
              <i class="${fab.icon}"></i>
            </button>
          </div>
        `).join('')}
      </div>
      <button id="main-fab" title="${state.isFabsOpen ? 'Close' : 'Open'}" class="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-primary text-white flex items-center justify-center text-3xl border-none shadow-lg shadow-accent/30 cursor-pointer transition-all duration-300 ease-in-out hover:from-primary hover:to-accent hover:shadow-xl hover:shadow-primary/40 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent animate-shine">
        <i class="fas ${state.isFabsOpen ? 'fa-times' : 'fa-plus'} transition-transform duration-300 ${state.isFabsOpen ? 'rotate-90' : ''}"></i>
      </button>
    </div>
  `;
};

const MobileNavTemplate = () => {
    const serviceLinks = [
        { en: 'Business Operations', es: 'Operaciones'}, { en: 'Contact Center', es: 'Centro de Contacto'},
        { en: 'IT Support', es: 'Soporte IT'}, { en: 'Professionals', es: 'Profesionales'},
    ];
    return `
    <div id="mobile-nav-container" class="lg:hidden fixed bottom-4 right-4 z-[999] flex justify-end items-center">
      <div id="mobile-actions" class="flex items-center gap-3 transition-all duration-300 ease-in-out mr-3 ${state.isMobileMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-90 pointer-events-none'}">
        <button data-action="openModal('JOIN', { showBackdrop: false })" title="Join Us" class="w-14 h-14 shrink-0 rounded-full bg-white dark:bg-gray-700 text-accent dark:text-primary flex items-center justify-center text-2xl shadow-md transition-transform hover:scale-110"><i class="fa-thin fa-user-plus"></i></button>
        <button data-action="openModal('CONTACT', { showBackdrop: false })" title="Contact Us" class="w-14 h-14 shrink-0 rounded-full bg-white dark:bg-gray-700 text-accent dark:text-primary flex items-center justify-center text-2xl shadow-md transition-transform hover:scale-110"><i class="fa-thin fa-envelope"></i></button>
        <button data-action="openModal('CHATBOT', { showBackdrop: false })" title="Chatbot" class="w-14 h-14 shrink-0 rounded-full bg-white dark:bg-gray-700 text-accent dark:text-primary flex items-center justify-center text-2xl shadow-md transition-transform hover:scale-110"><i class="fa-thin fa-comment-dots"></i></button>
        <div class="relative">
          <button id="mobile-services-toggle" title="Services" class="w-14 h-14 shrink-0 rounded-full bg-white dark:bg-gray-700 text-accent dark:text-primary flex items-center justify-center text-2xl shadow-md transition-transform hover:scale-110"><i class="fa-thin fa-cogs"></i></button>
          <div id="mobile-services-panel" class="${state.isMobileServicesOpen ? '' : 'hidden'} absolute bottom-full right-0 mb-2 w-52 bg-gray-100/95 dark:bg-gray-900/95 backdrop-blur-sm rounded-2xl shadow-lg p-3">
            ${serviceLinks.map(link => `<a href="#" class="block text-gray-800 dark:text-gray-200 text-base py-1 px-2 rounded-md transition-colors hover:bg-gray-200 dark:hover:bg-gray-700">${link[state.language]}</a>`).join('')}
            <div class="h-px bg-gray-300 dark:bg-gray-600 my-1"></div>
            <button data-action="theme" class="w-full text-left text-gray-800 dark:text-gray-200 text-base py-1 px-2 rounded-md transition-colors hover:bg-gray-200 dark:hover:bg-gray-700 capitalize">${state.theme === 'light' ? 'Dark Mode' : 'Light Mode'}</button>
            <button data-action="lang" class="w-full text-left text-gray-800 dark:text-gray-200 text-base py-1 px-2 rounded-md transition-colors hover:bg-gray-200 dark:hover:bg-gray-700">Español / English</button>
          </div>
        </div>
      </div>
      <button id="mobile-main-fab" title="Menu" class="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-primary text-white flex items-center justify-center text-3xl shadow-lg cursor-pointer transition-all duration-300 ease-in-out hover:from-primary hover:to-accent animate-shine">
        <i class="fas ${state.isMobileMenuOpen ? 'fa-times' : 'fa-plus'} transition-transform duration-300 ${state.isMobileMenuOpen ? 'rotate-45' : ''}"></i>
      </button>
    </div>
  `;
};

const FooterTemplate = () => `
  <footer class="w-full bg-white/20 dark:bg-dark-footer/50 backdrop-blur-lg text-gray-800 dark:text-white text-base text-center py-4 fixed left-0 bottom-0 z-40 font-medium rounded-t-2xl tracking-wide border-t border-white/30 dark:border-white/10">
    © 2025 OPS Online Support
  </footer>
`;

// --- MODAL TEMPLATES --- //
const ModalWrapperTemplate = (content, { type, showBackdrop, modalClassName, backdropClassName }) => `
  <div id="modal-backdrop" class="fixed inset-0 z-[1000] modal-enter ${showBackdrop ? 'flex items-start justify-center pt-[5vh] bg-black/30 dark:bg-[#1a1930]/50 backdrop-blur-sm' : 'pointer-events-none'} ${backdropClassName || ''}" data-type="${type}">
    <div id="modal-content" class="fixed modal-content-enter ${!showBackdrop ? 'pointer-events-auto' : ''} ${modalClassName || ''}">
      ${content}
    </div>
  </div>
`;

const ServiceModalTemplate = (data) => {
    const d = data[state.language].modal;
    return `
    <div id="service-modal" class="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl p-8 pt-6 relative cursor-default">
      <button class="modal-close-btn absolute top-4 right-7 text-3xl font-bold text-accent border-none bg-none cursor-pointer z-10">&times;</button>
      <div id="service-modal-header" class="flex gap-5 items-center mb-4 cursor-move">
        <img src="${d.img}" alt="${d.imgAlt}" class="w-16 h-16 object-cover rounded-2xl border-2 border-accent/50" />
        <h2 class="text-xl font-bold uppercase tracking-wider">${d.title}</h2>
      </div>
      <div class="mb-4 text-base">${d.content}</div>
      <div class="bg-gray-100 dark:bg-dark-bg text-accent/80 dark:text-accent/60 rounded-xl mb-4 p-4 text-center">${d.video}</div>
      <ul class="mb-5 ml-5 list-disc space-y-1 text-base">${d.features.map(f => `<li>${f}</li>`).join('')}</ul>
      <div class="flex gap-3 justify-end flex-wrap mt-5">
        <a href="${d.learn}" target="_blank" class="modal-btn">${l('Learn More', 'Más Información')}</a>
        <button class="modal-btn" data-action="openModal('CHATBOT', { showBackdrop: false })">${l('Ask Chattia', 'Preguntar a Chattia')}</button>
        <button class="modal-btn-cta" data-action="openModal('CONTACT', { showBackdrop: false })">${l('Contact Us', 'Contáctanos')}</button>
        <button class="modal-btn modal-close-btn">${l('Cancel', 'Cancelar')}</button>
      </div>
    </div>`;
};

const JoinModalTemplate = () => `
  <div id="join-modal" class="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl p-6 relative max-h-[80vh] flex flex-col">
    <header id="join-modal-header" class="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-700 cursor-move">
      <h2 class="text-2xl font-bold text-primary">${l('Join Us', 'Únete a Nosotros')}</h2>
      <button class="modal-close-btn text-3xl font-bold text-accent/80 hover:text-accent">&times;</button>
    </header>
    <form id="join-form" class="overflow-y-auto flex-grow pr-2">
      <!-- Form content here -->
    </form>
  </div>
`;

const ContactModalTemplate = () => `
  <div id="contact-modal" class="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl p-6 relative max-h-[80vh] flex flex-col">
     <header id="contact-modal-header" class="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-700 cursor-move">
       <h2 class="text-2xl font-bold text-primary">${l('Contact Us', 'Contáctenos')}</h2>
       <button class="modal-close-btn text-3xl font-bold text-accent/80 hover:text-accent">&times;</button>
     </header>
     <form id="contact-form" class="space-y-4 overflow-y-auto flex-grow pr-2 mt-4">
        <!-- Form content here -->
     </form>
  </div>
`;

const ChatbotModalTemplate = () => `
  <div id="chatbot-modal" class="bg-dark-modal text-dark-text rounded-3xl shadow-2xl h-full flex flex-col overflow-hidden">
    <header id="chatbot-modal-header" class="flex justify-between items-center p-3 px-4 bg-gradient-to-r from-primary to-accent text-white font-semibold cursor-move select-none">
        <span>${l('OPS AI Chatbot', 'Chatbot OPS AI')}</span>
        <div class="flex items-center gap-2 text-sm">
            <button data-action="lang" class="opacity-90 hover:opacity-100">${l('ES', 'EN')}</button>
            <span>|</span>
            <button data-action="theme" class="opacity-90 hover:opacity-100 capitalize w-16 text-center">${l(state.theme === 'light' ? 'Dark' : 'Light', state.theme === 'light' ? 'Oscuro' : 'Claro')}</button>
            <button class="modal-close-btn ml-2 text-xl font-bold opacity-90 hover:opacity-100">&times;</button>
        </div>
    </header>
    <div id="chat-log" class="flex-1 overflow-y-auto p-4 bg-[#1b0e2d] text-sm space-y-4"></div>
    <div class="bg-[#220f3a] border-t border-accent/50 p-3">
        <form id="chatbot-form" class="flex items-center gap-2">
            <input type="text" id="chat-input" placeholder="${l('Type your message...', 'Escriba su mensaje...')}" class="flex-1 bg-transparent border-none text-white text-base p-2 focus:outline-none" required maxlength="256">
            <button type="submit" id="chat-submit" class="flex items-center justify-center w-10 h-10 bg-accent border-none text-white font-semibold rounded-lg cursor-pointer transition-all duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed group">
                <i class="fas fa-arrow-right"></i>
            </button>
        </form>
    </div>
  </div>
`;


// --- RENDER FUNCTION --- //
function render() {
    // Apply theme class
    document.documentElement.classList.toggle('dark', state.theme === 'dark');

    // Render main app structure
    $('#app-container').innerHTML = AppTemplate();
    
    // Render Modals
    const modalContainer = $('#modal-container');
    const { type, showBackdrop, data } = state.modal;

    if (type === 'NONE') {
        modalContainer.innerHTML = '';
        document.body.style.overflow = 'auto';
    } else {
        let modalContent = '';
        let modalClassName = `w-[96vw] max-w-lg min-w-[310px]`;
        let backdropClassName = '';
        const initialPosition = !showBackdrop ? 'right-4 bottom-28' : '';

        if (!showBackdrop) {
            modalClassName += ` ${initialPosition}`;
        }

        switch (type) {
            case 'SERVICE':
                modalContent = ServiceModalTemplate(data);
                break;
            case 'JOIN':
                modalContent = JoinModalTemplate();
                break;
            case 'CONTACT':
                modalContent = ContactModalTemplate();
                break;
            case 'CHATBOT':
                modalClassName += ` sm:h-[66vh] h-[80vh] max-h-[700px]`;
                backdropClassName = '!pt-0';
                modalContent = ChatbotModalTemplate();
                break;
        }

        modalContainer.innerHTML = ModalWrapperTemplate(modalContent, { type, showBackdrop, modalClassName, backdropClassName });
        if (showBackdrop) {
            document.body.style.overflow = 'hidden';
        }
    }
    
    attachEventListeners();
}

// --- EVENT LISTENERS & POST-RENDER LOGIC --- //
function attachEventListeners() {
    // Theme & Lang Toggles
    $('#lang-toggle')?.addEventListener('click', () => setState({ language: state.language === 'en' ? 'es' : 'en' }));
    $('#theme-toggle')?.addEventListener('click', () => {
        const newTheme = state.theme === 'light' ? 'dark' : 'light';
        localStorage.setItem('theme', newTheme);
        setState({ theme: newTheme });
    });

    // Service Cards
    $$('.service-card').forEach(card => card.addEventListener('click', (e) => {
        const key = e.currentTarget.dataset.serviceKey;
        openModal('SERVICE', { showBackdrop: true, data: SERVICES_DATA[key] });
    }));

    // FABs
    $('#main-fab')?.addEventListener('click', () => setState({ isFabsOpen: !state.isFabsOpen }));
    $$('#fabs-container .sub-fab button').forEach(btn => btn.addEventListener('click', e => {
        const action = e.currentTarget.dataset.action;
        new Function('openModal', '$', action)(openModal, $);
        setState({ isFabsOpen: false });
    }));

    // Mobile Nav
    $('#mobile-main-fab')?.addEventListener('click', () => {
        setState({ isMobileMenuOpen: !state.isMobileMenuOpen, isMobileServicesOpen: false });
    });
    $('#mobile-services-toggle')?.addEventListener('click', () => setState({ isMobileServicesOpen: !state.isMobileServicesOpen }));
    $$('#mobile-actions button[data-action], #mobile-services-panel button[data-action]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const action = e.currentTarget.dataset.action;
            if (action === 'theme') {
                const newTheme = state.theme === 'light' ? 'dark' : 'light';
                localStorage.setItem('theme', newTheme);
                setState({ theme: newTheme });
            } else if (action === 'lang') {
                setState({ language: state.language === 'en' ? 'es' : 'en' });
            } else {
                 new Function('openModal', action)(openModal);
            }
             setState({ isMobileMenuOpen: false, isMobileServicesOpen: false });
        });
    });

    // Modal Global Listeners
    const modalBackdrop = $('#modal-backdrop');
    if (modalBackdrop) {
        modalBackdrop.addEventListener('click', e => {
            if (e.target === modalBackdrop && state.modal.showBackdrop) closeModal();
        });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); }, { once: true });
    }
    $$('.modal-close-btn').forEach(btn => btn.addEventListener('click', closeModal));
    $$('[data-action^="openModal"]').forEach(btn => btn.addEventListener('click', e => {
        closeModal();
        setTimeout(() => new Function('openModal', e.currentTarget.dataset.action)(openModal), 50);
    }));

    // Post-render logic for specific modals
    postRenderJoinModal();
    postRenderContactModal();
    postRenderChatbotModal();
    postRenderServiceModal();
}

function postRenderServiceModal() {
    const modal = $('#service-modal');
    if(modal) {
        makeDraggable(modal, $('#service-modal-header'));
    }
}

function postRenderJoinModal() {
    const form = $('#join-form');
    if (form) {
        makeDraggable($('#join-modal'), $('#join-modal-header'));

        const DynamicSection = (title, placeholder) => {
            let items = [];
            let isAccepted = false;
            const sectionEl = document.createElement('div');
            
            const renderSection = () => {
                sectionEl.className = `p-4 mt-6 border rounded-lg ${isAccepted ? 'border-green-500' : 'border-dashed border-gray-400 dark:border-gray-600'}`;
                sectionEl.innerHTML = `
                  <div class="flex justify-between items-center mb-2">
                    <h3 class="font-semibold text-lg">${title}${isAccepted ? ' ✅' : ''}</h3>
                    ${!isAccepted ? `<div>
                      <button type="button" class="add-item w-7 h-7 rounded-full bg-primary text-white font-bold text-xl leading-none">+</button>
                      <button type="button" class="remove-item w-7 h-7 ml-2 rounded-full bg-red-500 text-white font-bold text-xl leading-none">-</button>
                    </div>` : ''}
                  </div>
                  <div class="space-y-2 item-inputs">
                    ${items.map((item, i) => `<input type="text" value="${item}" data-index="${i}" placeholder="${placeholder}" ${isAccepted ? 'disabled' : ''} class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent focus:border-transparent disabled:opacity-70">`).join('')}
                  </div>
                  ${items.length > 0 ? `<div class="mt-3">
                    ${isAccepted ? `<button type="button" class="edit-btn py-1 px-4 rounded bg-yellow-500 text-black font-semibold">${l('Edit', 'Editar')}</button>` : `<button type="button" class="accept-btn py-1 px-4 rounded bg-green-500 text-white font-semibold">${l('Accept', 'Aceptar')}</button>`}
                  </div>` : ''}`;
            };
            
            sectionEl.addEventListener('click', e => {
                if (e.target.classList.contains('add-item')) { items.push(''); renderSection(); }
                if (e.target.classList.contains('remove-item')) { items.pop(); renderSection(); }
                if (e.target.classList.contains('accept-btn')) { isAccepted = true; renderSection(); }
                if (e.target.classList.contains('edit-btn')) { isAccepted = false; renderSection(); }
            });
            sectionEl.addEventListener('input', e => {
                if(e.target.matches('input')) items[e.target.dataset.index] = e.target.value;
            });

            renderSection();
            return sectionEl;
        };

        form.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 mt-4">
                <div><label class="block text-sm font-medium mb-1">${l('Name','Nombre')}</label><input type="text" placeholder="${l('Your name','Tu nombre')}" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent"></div>
                <div><label class="block text-sm font-medium mb-1">${l('Email','Correo')}</label><input type="email" placeholder="${l('Your email','Tu correo')}" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent"></div>
                <div><label class="block text-sm font-medium mb-1">${l('Phone','Teléfono')}</label><input type="tel" placeholder="${l('Your phone','Tu teléfono')}" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent"></div>
            </div>
            <div id="dynamic-sections"></div>
            <div class="mt-6"><label class="block text-sm font-medium mb-1">${l('Interested in?','¿Interesado en?')}</label><select required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent"><option value="" disabled selected>${l('Select an option','Seleccione')}</option><option>${l('Business Operations','Operaciones')}</option><option>${l('Contact Center','Centro de Contacto')}</option><option>${l('IT Support','Soporte IT')}</option><option>${l('Professionals','Profesionales')}</option></select></div>
            <div class="mt-6"><label class="block text-sm font-medium mb-1">${l('About you','Sobre ti')}</label><textarea rows="4" placeholder="${l('Summary...','Resumen...')}" class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-accent"></textarea></div>
            <div class="flex justify-center pt-6 mt-4 border-t border-gray-200 dark:border-gray-700"><button type="submit" class="py-3 px-8 rounded-xl bg-primary text-white font-semibold hover:bg-accent-dark transition-colors shadow-lg hover:shadow-xl w-40">${l('Submit','Enviar')}</button></div>
        `;

        const dynamicContainer = $('#dynamic-sections', form);
        dynamicContainer.appendChild(DynamicSection(l('Skills', 'Habilidades'), l('Enter a skill', 'Ingrese una habilidad')));
        dynamicContainer.appendChild(DynamicSection(l('Education', 'Educación'), l('Enter degree', 'Ingrese título')));
        dynamicContainer.appendChild(DynamicSection(l('Certifications', 'Certificaciones'), l('Enter a certification', 'Ingrese certificación')));

        form.addEventListener('submit', e => { e.preventDefault(); alert('Submitted!'); closeModal(); });
    }
}

function postRenderContactModal() {
    const form = $('#contact-form');
    if (form) {
        makeDraggable($('#contact-modal'), $('#contact-modal-header'));
        form.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                <div><label class="block text-sm font-medium mb-1">${l('Name','Nombre')}</label><input type="text" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary"></div>
                <div><label class="block text-sm font-medium mb-1">${l('Email','Correo')}</label><input type="email" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary"></div>
                <div><label class="block text-sm font-medium mb-1">${l('Contact Number','Número')}</label><input type="tel" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary"></div>
                <div><label class="block text-sm font-medium mb-1">${l('Preferred Date','Fecha')}</label><input type="date" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary"></div>
                <div><label class="block text-sm font-medium mb-1">${l('Preferred Time','Hora')}</label><input type="time" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary"></div>
                <div><label class="block text-sm font-medium mb-1">${l('I am interested in...','Interesado en...')}</label><select required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary"><option value="" disabled selected>${l('Select a service','Seleccione')}</option><option>${l('Business Operations','Operaciones')}</option><option>${l('Contact Center','Centro de Contacto')}</option><option>${l('IT Support','Soporte IT')}</option><option>${l('Professionals','Profesionales')}</option></select></div>
            </div>
            <div class="pt-2"><label class="block text-sm font-medium mb-1">${l('Comments','Comentarios')}</label><textarea rows="4" required class="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary"></textarea></div>
            <div class="flex justify-center gap-3 pt-6 mt-4 border-t border-gray-200 dark:border-gray-700"><button type="button" class="modal-close-btn py-3 px-8 rounded-xl bg-gray-200 dark:bg-gray-600 font-semibold hover:bg-gray-300 dark:hover:bg-gray-500">${l('Cancel','Cancelar')}</button><button type="submit" class="py-3 px-8 rounded-xl bg-primary text-white font-semibold hover:bg-cyan-500">${l('Send','Enviar')}</button></div>
        `;
        form.addEventListener('submit', e => { e.preventDefault(); alert('Sent!'); closeModal(); });
    }
}

let chatbotState = { messages: [], isLoading: false };
function postRenderChatbotModal() {
    const modal = $('#chatbot-modal');
    if (modal) {
        makeDraggable(modal, $('#chatbot-modal-header'));

        if (chatbotState.messages.length === 0) {
            chatbotState.messages.push({ role: 'system', text: l('Welcome to OPS! How can I assist you today?', '¡Bienvenido a OPS! ¿Cómo puedo ayudarte hoy?') });
        }
        
        const chatLog = $('#chat-log');
        const chatForm = $('#chatbot-form');
        const chatInput = $('#chat-input');
        const chatSubmit = $('#chat-submit');

        const renderMessages = () => {
            chatLog.innerHTML = chatbotState.messages.map((msg, index) => {
                const isLoading = chatbotState.isLoading && index === chatbotState.messages.length - 1;
                return `
                    <div class="max-w-[90%] w-fit py-2 px-3.5 rounded-2xl ${
                        msg.role === 'user' ? 'ml-auto bg-primary text-black rounded-br-none'
                        : msg.role === 'bot' ? 'mr-auto bg-[#321b53] text-white rounded-bl-none whitespace-pre-wrap'
                        : 'mx-auto bg-transparent text-accent/80 text-center text-xs'
                    }">
                       ${msg.text}
                       ${isLoading ? '<span class="inline-block w-2 h-2 ml-1 bg-white rounded-full animate-pulse"></span>' : ''}
                    </div>
                `;
            }).join('');
            chatLog.scrollTop = chatLog.scrollHeight;
        };

        chatForm.onsubmit = async (e) => {
            e.preventDefault();
            const input = chatInput.value.trim();
            if (!input || chatbotState.isLoading) return;

            chatbotState.messages.push({ role: 'user', text: input });
            const currentInput = input;
            chatInput.value = '';
            chatbotState.isLoading = true;
            chatSubmit.disabled = true;
            renderMessages();

            chatbotState.messages.push({ role: 'bot', text: '' });
            renderMessages();

            await streamChatResponse(chatbotState.messages, currentInput, (chunk) => {
                chatbotState.messages[chatbotState.messages.length - 1].text = chunk;
                renderMessages();
            });

            chatbotState.isLoading = false;
            chatSubmit.disabled = false;
            renderMessages();
        };

        renderMessages();
    } else {
        chatbotState = { messages: [], isLoading: false }; // Reset on close
    }
}

// --- INITIALIZATION --- //
function init() {
    const storedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const storedLang = localStorage.getItem('language');

    state.theme = storedTheme || (prefersDark ? 'dark' : 'light');
    state.language = storedLang || 'en';

    render();
}

document.addEventListener('DOMContentLoaded', init);
