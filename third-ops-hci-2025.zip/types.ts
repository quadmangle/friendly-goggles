
import type React from 'react';

export type Language = 'en' | 'es';
export type Theme = 'light' | 'dark';
export type ServiceKey = 'ops' | 'cc' | 'it' | 'pro';
export type ModalType = 'NONE' | 'SERVICE' | 'JOIN' | 'CONTACT' | 'CHATBOT';

export interface ServiceModalData {
  title: string;
  img: string;
  imgAlt: string;
  content: string;
  video: string;
  features: string[];
  learn: string;
}

export interface ServiceContent {
  title: string;
  icon: string; // Now a className string, e.g., "fa-thin fa-briefcase"
  desc: string;
  modal: ServiceModalData;
}

export interface ServiceData {
  en: ServiceContent;
  es: ServiceContent;
}

export interface Services {
  ops: ServiceData;
  cc: ServiceData;
  it: ServiceData;
  pro: ServiceData;
}

export interface GlobalContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  showBackdrop?: boolean;
}

export interface ChatMessage {
  role: 'user' | 'bot' | 'system';
  text: string;
}