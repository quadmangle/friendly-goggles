import { GoogleGenAI, Chat } from "@google/genai";
import type { ChatMessage } from '../types';

/**
 * This file contains the implementation for connecting to Google's Gemini API.
 * To use this, you would integrate this service back into the application,
 * for example by replacing the logic in `services/geminiService.ts` with this,
 * and ensuring the API_KEY is available in the environment.
 */

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real scenario, you might want to handle this more gracefully than throwing an error
  // that stops the script, but for this separated module, it makes the dependency clear.
  console.error("API_KEY for Google AI is not set. This service cannot function without it.");
}

// Ensure ai is only initialized if API_KEY exists
const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

let chat: Chat | null = null;

const initializeChat = () => {
  if (!ai) return null;
  if (!chat) {
    chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: "You are 'Chattia', a helpful and friendly AI assistant for OPS, a company providing Business Operations, Contact Center, IT Support, and Professional services. Your tone is professional yet approachable. Keep responses concise and to the point. You can answer questions about the company's services. Do not make up information you don't know. If asked something unrelated to OPS, politely decline.",
      },
    });
  }
  return chat;
};


export const streamChatResponseWithGoogleAI = async (history: ChatMessage[], newMessage: string, onChunk: (chunk: string) => void) => {
    if (!ai) {
        onChunk("The AI service is not configured. Please ensure an API key is provided.");
        return;
    }
    
    try {
        const chatInstance = initializeChat();
        if(!chatInstance) throw new Error("Chat could not be initialized.");

        const stream = await chatInstance.sendMessageStream({ message: newMessage });
        let text = '';
        for await (const chunk of stream) {
            text += chunk.text;
            onChunk(text);
        }
    } catch (error) {
        console.error("Error streaming chat response from Google AI:", error);
        onChunk("I'm sorry, I'm having trouble connecting to the AI service right now. Please try again later.");
    }
};

export const resetGoogleAIChat = () => {
    chat = null;
};
